package com.huize.jvm.memory;

public class Test {
	
	private Integer a = new Integer(10);

}
