package com.huize.jvm.bytecode.example;

public class Test {

	private int a = 0;
	
	public int add(int b) {
		return a + b;
	}
}
