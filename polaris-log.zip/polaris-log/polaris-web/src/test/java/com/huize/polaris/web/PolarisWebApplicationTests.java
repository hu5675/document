package com.huize.polaris.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolarisWebApplicationTests {

    @Test
    void contextLoads() {
    }

}
